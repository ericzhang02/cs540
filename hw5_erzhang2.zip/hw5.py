import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import sys


def createPlot(data):
    plt.plot = data.plot.line(x = "year", y = "days")
    plt.xlabel('years')
    plt.ylabel('Number of frozen days') 
    plt.savefig("plot.jpg")
    
    
if __name__ == "__main__":
    dataFile = sys.argv[1]
    lake_df = pd.read_csv(dataFile, encoding="utf-8")

    createPlot(lake_df)
    
    yearTemp = np.array(lake_df["year"])
    X = []
    for i in yearTemp:
        X.append([1, i])
    X = np.array(X)
    print("Q3a:")
    print(X)
    
    Y = np.array(lake_df["days"])
    print("Q3b")
    print(Y)
    
    Z = np.matmul(np.transpose(X),X)
    print("Q3c")
    print(Z)
    
    I = np.linalg.inv(Z)
    print("Q3d:")
    print(I)
    
    PI = np.matmul(I, np.transpose(X))
    print("Q3e:")
    print(PI)
    
    hat_beta = np.matmul(PI,Y)
    print(hat_beta)
    
    y_test = hat_beta[0]+hat_beta[1]*2022
    print("Q4:"+str(y_test))
    
    print("Q5a: <")
    print("Q5b: the meaning of this sign is that the days which Mendota ice is frozen is decreasing for each passing year as hat_beta 1 is negative")
    
    X_Star = hat_beta[0]/(-1*hat_beta[1])
    print("Q6a: " + str(X_Star))
    print("Q6b: X* or the year ~2455 could be possible for the day that the Mendota ice doesn't freeze but it's rather unlikely. Our data set only contains about 200 years but it's trying to predict thousands of years into the future. The small sample size doesnt really hold up. Another aspect is that this model is linear. In a case with more data, we might find that a exponential or logrithmic curve works better. While the model is somewhat realistic, there are too many factors to consider in reality.")