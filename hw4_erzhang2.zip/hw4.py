import csv
import numpy as np
import copy
import matplotlib.pyplot as plt
from scipy.cluster.hierarchy import dendrogram, linkage

def load_data(filepath):
    with open(filepath, 'r') as file:
        csvreader = csv.DictReader(file)
        return list(csvreader)

def calc_features(row):
    pkmArray = np.array([row['HP'],row['Attack'],row['Defense'],row['Sp. Atk'],row['Sp. Def'],row['Speed']], dtype="int64")
    return pkmArray

def hac(features):
    arrToReturn = []
    arrDistace = getDistanceArray(features)
    arrCluster = getClusterArray(len(features))
    clusterHistory = []
    size = len(features)
    iteration = 0
    while iteration < len(features)-1:
        a, b, dist, clusterSize, arrCluster, clusterHistory = cluster(arrCluster, arrDistace, clusterHistory, size)
        if a > b:
            a,b = b,a
        arrToReturn.append([a, b, dist, len(arrCluster[-1])])
        iteration += 1
    return np.array(arrToReturn)
    
    
def imshow_hac(Z, names):
    plt.figure(figsize=(15,10))
    plt.title("N = " + str(len(names)))
    plt.tight_layout()
    dendrogram(
        Z = Z,
        leaf_rotation=(90),
        labels=(names)
    )
    plt.show()
    
def cluster(arrCluster, arrDistace, clusterHistory, size):
    clusterA, clusterB, dist = nextCluster(arrCluster, arrDistace)
    arrCluster.remove(clusterA)
    arrCluster.remove(clusterB)
    arrCluster.append(clusterA + clusterB)
    numberA = -1
    numberB = -1
    dist = -1
    for a in clusterA:
        for b in clusterB:
            if arrDistace[a][b] > dist:
                dist = arrDistace[a][b]
                numberA = a
                numberB = b
    countA = len(clusterHistory) - 1
    while countA > -1:
        if numberA in clusterHistory[countA][1]:
            numberA = clusterHistory[countA][0]
            break
        countA -= 1
    countB = len(clusterHistory) - 1
    while countB > -1:
        if numberB in clusterHistory[countB][1]:
            numberB = clusterHistory[countB][0]
            break
        countB -= 1
    if(numberA > numberB):
        numberA, numberB = numberB, numberA()
    clusterHistory.append([size+len(clusterHistory), clusterA + clusterB])
    return numberA, numberB, dist, len(clusterA + clusterB), arrCluster, clusterHistory
    
def nextCluster(arrClusters, arrDistace):
    clusterA = arrClusters[0]
    clusterB = arrClusters[1]
    currDist = 9999999
    currClusterA = 0;
    while currClusterA < len(arrClusters)-1:
        currClusterB = currClusterA + 1
        while currClusterB < len(arrClusters):
            if clusterdist(arrClusters[currClusterA], arrClusters[currClusterB], arrDistace) < currDist and not(clusterA == clusterB):
                currDist = clusterdist(arrClusters[currClusterA], arrClusters[currClusterB], arrDistace)
                clusterA = arrClusters[currClusterA]
                clusterB = arrClusters[currClusterB]
            currClusterB += 1
        currClusterA += 1
    return clusterA, clusterB, currDist
    
def clusterdist(clusterA, clusterB, arrDistace):
    dist = 0
    for itemA in clusterA:
        for itemB in clusterB:
            if arrDistace[itemA][itemB] > dist:
                dist = arrDistace[itemA][itemB]
    return dist

def distance(array1, array2):
    return np.linalg.norm(array1-array2)

def getClusterArray(size):
    arr = []
    x = 0
    while x < size:
        arr.append([x])
        x += 1
    return arr

def getDistanceArray(features):
    arrOfDist = []
    row = 0
    while row < len(features):
        arrToAppend = []
        col = 0
        while col <  len(features):
            arrToAppend.append(distance(features[row], features[col]))
            col += 1
        arrOfDist.append(arrToAppend)
        row += 1
    return arrOfDist 

