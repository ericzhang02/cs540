
from scipy.linalg import eigh
import numpy as np
import matplotlib.pyplot as plt

def load_and_center_dataset(filename):
    x = np.load(filename)
    x = x-np.mean(x,axis = 0)
    return x

def get_covariance(dataset):
    return (np.dot(np.transpose(dataset), dataset)/(len(dataset)- 1))


def get_eig(S, m):
    Lambda, U = eigh(S,subset_by_index=[len(S)-m,len(S)-1])
    i = np.flip(np.argsort(Lambda))
    return np.diag(Lambda[i]), U[:,i]
    

def get_eig_prop(S, prop):
    Lambda, U = eigh(S)
    limit = np.sum(Lambda) * prop
    Lambda, U = eigh(S, subset_by_value=[limit, np.inf])
    i = np.flip(np.argsort(Lambda))
    return np.diag(Lambda[i]), U[:, i]

def project_image(image, U):
    x = np.dot(np.transpose(U), image)
    return np.dot(U, x)

def display_image(orig, proj):
    orig = np.reshape(orig,(32,32))
    orig = np.transpose(orig)
    proj = np.reshape(proj,(32,32))
    proj = np.transpose(proj)
    fig, (ax1,ax2) = plt.subplots(nrows = 1, ncols = 2)
    ax1.set_title('Original')
    ax2.set_title('projection')
    ax1M = ax1.imshow(orig, aspect='equal')
    fig.colorbar(ax1M, ax = ax1, shrink = .57)
    ax2M = ax2.imshow(proj, aspect='equal')
    fig.colorbar(ax2M, ax = ax2, shrink = .57)
    plt.show()

